function testLaunch() {
console.info("Button clicked");
confirm("Are you want to delete?");
}
