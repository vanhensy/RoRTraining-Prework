function testLaunch() {
console.info("Button clicked");
alert("Are you sure ?");
}
